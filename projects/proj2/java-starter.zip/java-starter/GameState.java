public enum GameState {
    IN_PROGRESS, MAX_WIN, MIN_WIN, TIE;
}

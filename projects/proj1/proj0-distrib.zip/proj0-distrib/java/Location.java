record Location(long id, double latitude, double longitude) {
}
